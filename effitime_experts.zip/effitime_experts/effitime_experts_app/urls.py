from django.urls import path
from .views import RegisterView, LoginView, TimesheetView, LeadTimesheetView,ManagerTimesheetView,EmployeeDetailView,ProjectListView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('timesheet/', TimesheetView.as_view(), name='timesheet'),
    path('lead-timesheets/', LeadTimesheetView.as_view(), name='lead-timesheets'),
    path('lead-timesheets/<int:timesheet_id>/', LeadTimesheetView.as_view(), name='lead-timesheet-update'),
    path('manager-timesheets/', ManagerTimesheetView.as_view(), name='manager-timesheets-list'),
    path('manager-timesheets/<int:timesheet_id>/', ManagerTimesheetView.as_view(), name='manager-timesheet-detail'),
    path('employee/<int:emp_id>/', EmployeeDetailView.as_view(), name='employee-detail'),
    path('projects/', ProjectListView.as_view(), name='projects-list'),

]

